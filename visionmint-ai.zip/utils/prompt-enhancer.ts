export const STYLE_PRESETS = {
  photorealistic: {
    label: 'Photorealistic',
    prefix: 'photorealistic, ultra-detailed, DSLR photography, 8K resolution, cinematic lighting, professional photo',
    suffix: 'hyperrealistic, sharp focus, high dynamic range',
  },
  'digital-art': {
    label: 'Digital Art',
    prefix: 'digital art, concept art, highly detailed illustration, vibrant colors, trending on ArtStation',
    suffix: 'by Greg Rutkowski, digital painting, masterpiece',
  },
  'anime': {
    label: 'Anime',
    prefix: 'anime style, manga art, Studio Ghibli inspired, beautiful anime illustration',
    suffix: 'high quality anime art, vivid colors, detailed',
  },
  'oil-painting': {
    label: 'Oil Painting',
    prefix: 'oil painting, classical art style, museum quality, old masters technique',
    suffix: 'fine art, textured brushstrokes, masterpiece painting',
  },
  'watercolor': {
    label: 'Watercolor',
    prefix: 'watercolor painting, soft washes, artistic, delicate watercolor illustration',
    suffix: 'transparent washes, paper texture, artistic watercolor',
  },
  'fantasy': {
    label: 'Fantasy Art',
    prefix: 'epic fantasy art, magical, mystical atmosphere, fantasy world',
    suffix: 'magical realism, epic scale, highly detailed fantasy illustration',
  },
  'cyberpunk': {
    label: 'Cyberpunk',
    prefix: 'cyberpunk art style, neon lights, futuristic dystopia, blade runner aesthetic',
    suffix: 'neon glow, rain-slicked streets, high tech low life, cinematic',
  },
  'minimalist': {
    label: 'Minimalist',
    prefix: 'minimalist design, clean lines, simple composition, negative space',
    suffix: 'elegant simplicity, modern minimalism, clean aesthetic',
  },
} as const;

export type StyleKey = keyof typeof STYLE_PRESETS;

export const ASPECT_RATIOS = {
  '1:1': { label: '1:1 Square', width: 1024, height: 1024 },
  '16:9': { label: '16:9 Landscape', width: 1344, height: 768 },
  '9:16': { label: '9:16 Portrait', width: 768, height: 1344 },
  '4:3': { label: '4:3 Standard', width: 1152, height: 896 },
} as const;

export type AspectRatioKey = keyof typeof ASPECT_RATIOS;

export const AI_MODELS = {
  'stabilityai/stable-diffusion-xl-base-1.0': {
    label: 'SDXL Base (Best Quality)',
    description: 'Highest quality, slower',
  },
  'runwayml/stable-diffusion-v1-5': {
    label: 'SD v1.5 (Fast)',
    description: 'Faster generation',
  },
  'stabilityai/stable-diffusion-2-1': {
    label: 'SD v2.1',
    description: 'Balanced quality and speed',
  },
} as const;

export type ModelKey = keyof typeof AI_MODELS;

export function enhancePrompt(userPrompt: string, style: StyleKey): string {
  const styleConfig = STYLE_PRESETS[style] || STYLE_PRESETS.photorealistic;
  return `${styleConfig.prefix}, ${userPrompt}, ${styleConfig.suffix}, high quality, professional, masterpiece`;
}

export function getNegativePrompt(): string {
  return 'blurry, low quality, distorted, deformed, ugly, bad anatomy, watermark, signature, text, logo, duplicate, mutation, extra limbs, poorly drawn, disfigured, gross proportions, malformed limbs, missing arms, missing legs, extra arms, extra legs, mutated hands, fused fingers, too many fingers, long neck';
}

export const EXAMPLE_PROMPTS = [
  'A magical forest at twilight with glowing fireflies and ancient trees',
  'Futuristic city skyline at night with neon reflections on wet streets',
  'A majestic dragon perched on a mountain peak above the clouds',
  'Cozy coffee shop interior with warm lighting and rain on the windows',
  'An astronaut floating in space with colorful nebulae in the background',
  'Beautiful Japanese cherry blossom garden with a traditional temple',
  'A steampunk airship flying over Victorian London at sunset',
  'Underwater city with bioluminescent marine life and ancient ruins',
];
