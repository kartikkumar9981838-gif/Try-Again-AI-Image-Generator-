'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Sparkles, Menu, X, Zap } from 'lucide-react';
import { cn } from '@/utils/cn';

interface NavbarProps {
  user?: { email: string; credits?: number } | null;
}

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/dashboard', label: 'Generate' },
  { href: '/#pricing', label: 'Pricing' },
  { href: '/history', label: 'History' },
];

export default function Navbar({ user }: NavbarProps) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <nav className={cn('navbar transition-all duration-300', scrolled && 'shadow-[0_4px_30px_rgba(0,0,0,0.5)]')}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-accent-purple to-accent-cyan flex items-center justify-center shadow-glow-sm group-hover:shadow-glow-purple transition-all duration-300">
              <Sparkles className="w-4 h-4 text-white" />
              <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-accent-purple to-accent-cyan opacity-0 group-hover:opacity-50 blur-lg transition-opacity duration-300" />
            </div>
            <span className="font-display text-lg font-bold gradient-text">VisionMint</span>
            <span className="text-xs badge badge-purple hidden sm:flex">AI</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm text-text-secondary hover:text-white rounded-lg hover:bg-white/5 transition-all duration-200"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Right Side */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-sm">
                  <Zap className="w-3.5 h-3.5 text-accent-cyan" />
                  <span className="text-sm font-semibold text-accent-cyan">{user.credits ?? 10}</span>
                  <span className="text-xs text-text-secondary">credits</span>
                </div>
                <Link href="/dashboard" className="btn-glow px-4 py-2 text-sm rounded-xl relative z-10">
                  Dashboard
                </Link>
              </>
            ) : (
              <>
                <Link href="/auth/login" className="px-4 py-2 text-sm text-text-secondary hover:text-white transition-colors">
                  Log in
                </Link>
                <Link href="/auth/signup" className="btn-glow px-5 py-2 text-sm rounded-xl relative z-10">
                  Get Started Free
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden p-2 rounded-lg text-text-secondary hover:text-white hover:bg-white/5 transition-all"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="md:hidden glass border-t border-white/5 px-4 py-4 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="block px-4 py-2.5 text-text-secondary hover:text-white hover:bg-white/5 rounded-lg transition-all"
            >
              {link.label}
            </Link>
          ))}
          <div className="pt-2 border-t border-white/5 space-y-2">
            {user ? (
              <Link href="/dashboard" onClick={() => setOpen(false)} className="btn-glow block text-center px-4 py-2.5 text-sm rounded-xl relative z-10">
                Dashboard
              </Link>
            ) : (
              <>
                <Link href="/auth/login" onClick={() => setOpen(false)} className="block text-center px-4 py-2.5 text-sm text-text-secondary hover:text-white transition-colors">
                  Log in
                </Link>
                <Link href="/auth/signup" onClick={() => setOpen(false)} className="btn-glow block text-center px-4 py-2.5 text-sm rounded-xl relative z-10">
                  Get Started Free
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
