import Link from 'next/link';
import { Check, Zap } from 'lucide-react';

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Perfect for trying out VisionMint AI',
    credits: 10,
    features: [
      '10 image generations/month',
      '3 art style presets',
      'Standard quality (1024px)',
      'Image history (7 days)',
      'Download generated images',
      'Community support',
    ],
    cta: 'Start for Free',
    href: '/auth/signup',
    highlight: false,
  },
  {
    name: 'Pro',
    price: '$9',
    period: '/month',
    description: 'For creators and content makers',
    credits: 200,
    features: [
      '200 image generations/month',
      'All 8 art style presets',
      'High quality (1344px)',
      'Unlimited history',
      'Priority generation queue',
      'Batch generation (4 at once)',
      'Commercial usage rights',
      'Priority email support',
    ],
    cta: 'Get Pro',
    href: '/auth/signup?plan=pro',
    highlight: true,
  },
  {
    name: 'Team',
    price: '$29',
    period: '/month',
    description: 'For teams and businesses',
    credits: 1000,
    features: [
      '1000 image generations/month',
      'All Pro features',
      'API access',
      'Team management (5 seats)',
      'Custom style training',
      'White-label exports',
      'Priority support + SLA',
      'Invoice billing',
    ],
    cta: 'Contact Sales',
    href: '/contact',
    highlight: false,
  },
];

export default function PricingSection() {
  return (
    <section id="pricing" className="relative py-24 sm:py-32 px-4 sm:px-6">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-accent-purple/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center badge badge-purple mb-4">
            Simple Pricing
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold mb-5">
            Start Free, Scale When Ready
          </h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">
            No hidden fees. Cancel anytime. Start generating images today at no cost.
          </p>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative glass p-7 flex flex-col ${
                plan.highlight
                  ? 'border-accent-purple/40 shadow-glow-purple ring-1 ring-accent-purple/30'
                  : ''
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <span className="badge badge-purple text-xs px-4 py-1 shadow-glow-sm">
                    ⭐ Most Popular
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-bold text-white mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-4xl font-bold font-display gradient-text-purple">{plan.price}</span>
                  <span className="text-text-secondary text-sm">{plan.period}</span>
                </div>
                <p className="text-text-secondary text-sm">{plan.description}</p>
                <div className="flex items-center gap-1.5 mt-3">
                  <Zap className="w-4 h-4 text-accent-cyan" />
                  <span className="text-sm font-semibold text-accent-cyan">{plan.credits.toLocaleString()} credits</span>
                </div>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <Check className="w-4 h-4 text-accent-cyan mt-0.5 shrink-0" />
                    <span className="text-sm text-text-secondary">{f}</span>
                  </li>
                ))}
              </ul>

              <Link
                href={plan.href}
                className={`text-center py-3 rounded-xl text-sm font-semibold transition-all duration-300 ${
                  plan.highlight
                    ? 'btn-glow relative z-10'
                    : 'glass-sm border border-white/10 hover:border-accent-purple/40 hover:text-white text-text-secondary'
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
