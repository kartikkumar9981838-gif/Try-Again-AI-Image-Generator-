import type { Metadata, Viewport } from 'next';
import { Playfair_Display, DM_Sans, DM_Mono } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
});

const dmMono = DM_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400', '500'],
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://visionmint.ai'),
  title: {
    default: 'VisionMint AI — Free AI Image Generator | Text to Image',
    template: '%s | VisionMint AI',
  },
  description:
    'VisionMint AI is a free AI image generator that turns text prompts into stunning, high-quality images in seconds. No signup required to try. Perfect for creators, marketers, and artists.',
  keywords: [
    'AI image generator',
    'text to image AI',
    'free AI art generator',
    'AI photo creator',
    'AI image maker',
    'stable diffusion online',
    'AI art tool',
    'generate images from text',
    'free text to image',
    'AI image generation online',
  ],
  authors: [{ name: 'VisionMint AI' }],
  creator: 'VisionMint AI',
  publisher: 'VisionMint AI',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: '/',
    siteName: 'VisionMint AI',
    title: 'VisionMint AI — Free AI Image Generator | Text to Image',
    description:
      'Turn your text prompts into stunning AI-generated images instantly. Free, fast, and high quality.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'VisionMint AI — AI Image Generator',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'VisionMint AI — Free AI Image Generator',
    description: 'Turn text into stunning AI images for free. Fast, creative, powerful.',
    images: ['/og-image.png'],
    creator: '@visionmintai',
  },
  alternates: {
    canonical: '/',
  },
};

export const viewport: Viewport = {
  themeColor: '#7C3AED',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${playfair.variable} ${dmSans.variable} ${dmMono.variable}`}>
      <body className="bg-bg-primary text-text-primary font-body antialiased">
        {children}
      </body>
    </html>
  );
}
