'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Sparkles, ArrowRight, Zap } from 'lucide-react';
import { EXAMPLE_PROMPTS } from '@/utils/prompt-enhancer';

export default function HeroSection() {
  const [prompt, setPrompt] = useState('');
  const router = useRouter();

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    const encoded = encodeURIComponent(prompt.trim());
    router.push(`/dashboard?prompt=${encoded}`);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
      {/* Animated background orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent-purple/10 rounded-full blur-[100px] animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent-cyan/8 rounded-full blur-[100px] animate-float animation-delay-300" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent-purple/5 rounded-full blur-[120px]" />

        {/* Grid overlay */}
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(rgba(124,58,237,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(124,58,237,0.04) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 badge badge-purple mb-6 animate-pulse-glow">
          <Zap className="w-3 h-3" />
          Powered by Stable Diffusion XL
        </div>

        {/* Headline */}
        <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold leading-[1.05] tracking-tight mb-6 text-balance">
          Turn Text Into{' '}
          <span className="gradient-text">Stunning</span>
          <br />AI Images
        </h1>

        {/* Subtitle */}
        <p className="text-text-secondary text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
          Describe anything — VisionMint AI transforms your words into breathtaking, 
          high-quality visuals in seconds. No design skills needed.
        </p>

        {/* Main Input */}
        <form onSubmit={handleGenerate} className="max-w-2xl mx-auto mb-6">
          <div className="relative glass p-2 rounded-2xl shadow-[0_0_0_1px_rgba(124,58,237,0.2),0_20px_60px_rgba(0,0,0,0.5)] hover:shadow-[0_0_0_1px_rgba(124,58,237,0.4),0_20px_60px_rgba(0,0,0,0.5)] transition-all duration-300">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A magical forest at twilight with glowing fireflies..."
              rows={3}
              className="w-full bg-transparent px-4 pt-3 pb-2 text-white placeholder-text-muted resize-none focus:outline-none text-base leading-relaxed"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleGenerate(e as unknown as React.FormEvent);
                }
              }}
            />
            <div className="flex items-center justify-between px-2 pb-1">
              <p className="text-xs text-text-muted">{prompt.length}/500 • Press Enter or click Generate</p>
              <button
                type="submit"
                disabled={!prompt.trim()}
                className="btn-glow flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-xl relative z-10 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-none disabled:hover:transform-none"
              >
                <Sparkles className="w-4 h-4" />
                Generate
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </form>

        {/* Example Prompts */}
        <div className="flex flex-wrap justify-center gap-2 max-w-2xl mx-auto">
          <span className="text-xs text-text-muted self-center mr-1">Try:</span>
          {EXAMPLE_PROMPTS.slice(0, 4).map((p, i) => (
            <button
              key={i}
              onClick={() => setPrompt(p)}
              className="text-xs px-3 py-1.5 glass-sm hover:border-accent-purple/30 text-text-secondary hover:text-white transition-all duration-200 truncate max-w-[200px]"
            >
              {p.length > 35 ? p.slice(0, 35) + '…' : p}
            </button>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-16 flex flex-wrap justify-center gap-8 sm:gap-12">
          {[
            { label: 'Images Generated', value: '50K+' },
            { label: 'Active Users', value: '5K+' },
            { label: 'AI Models', value: '3' },
            { label: 'Always Free', value: '✓' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl sm:text-3xl font-bold gradient-text-purple font-display">{stat.value}</div>
              <div className="text-sm text-text-secondary mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
