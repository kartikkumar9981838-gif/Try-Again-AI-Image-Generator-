import type { Metadata } from 'next';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import HeroSection from '@/components/ui/HeroSection';
import FeaturesSection from '@/components/ui/FeaturesSection';
import GallerySection from '@/components/ui/GallerySection';
import PricingSection from '@/components/ui/PricingSection';

export const metadata: Metadata = {
  title: 'VisionMint AI — Free AI Image Generator | Text to Image Art',
  description:
    'Create stunning AI-generated images from text prompts for free. VisionMint AI uses Stable Diffusion to turn your ideas into beautiful artwork in seconds.',
  alternates: { canonical: '/' },
};

export default function HomePage() {
  return (
    <div className="mesh-bg min-h-screen">
      <Navbar />

      <main>
        <HeroSection />

        {/* Divider */}
        <div className="section-divider max-w-5xl mx-auto" />

        <FeaturesSection />

        <div className="section-divider max-w-5xl mx-auto" />

        <GallerySection />

        <div className="section-divider max-w-5xl mx-auto" />

        <PricingSection />

        {/* Final CTA Banner */}
        <section className="py-24 px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="glass p-10 sm:p-14 rounded-3xl border-accent-purple/20 shadow-[0_0_80px_rgba(124,58,237,0.15)]">
              <h2 className="font-display text-4xl sm:text-5xl font-bold mb-5">
                Ready to Create Something Amazing?
              </h2>
              <p className="text-text-secondary text-lg mb-8">
                Join thousands of creators generating stunning AI art every day. 
                Start free — no credit card required.
              </p>
              <a
                href="/dashboard"
                className="btn-glow inline-flex items-center gap-2 px-10 py-4 text-base font-bold rounded-2xl relative z-10"
              >
                ✨ Start Creating for Free
              </a>
              <p className="text-xs text-text-muted mt-4">10 free generations • No signup required to try</p>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
