import Link from 'next/link';
import { Sparkles, Twitter, Github, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-purple to-accent-cyan flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-display text-lg font-bold gradient-text">VisionMint AI</span>
            </Link>
            <p className="text-text-secondary text-sm leading-relaxed">
              Turn your ideas into stunning AI-generated images. Free, fast, and creative.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="https://twitter.com/visionmintai" target="_blank" rel="noopener noreferrer"
                className="p-2 rounded-lg glass-sm hover:border-accent-purple/30 transition-all group">
                <Twitter className="w-4 h-4 text-text-secondary group-hover:text-accent-cyan transition-colors" />
              </a>
              <a href="https://github.com/visionmintai" target="_blank" rel="noopener noreferrer"
                className="p-2 rounded-lg glass-sm hover:border-accent-purple/30 transition-all group">
                <Github className="w-4 h-4 text-text-secondary group-hover:text-accent-purple transition-colors" />
              </a>
            </div>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">Product</h3>
            <ul className="space-y-2.5">
              {[
                { href: '/dashboard', label: 'AI Generator' },
                { href: '/history', label: 'My Gallery' },
                { href: '/#pricing', label: 'Pricing' },
                { href: '/#features', label: 'Features' },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-text-secondary hover:text-white transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">Resources</h3>
            <ul className="space-y-2.5">
              {[
                { href: '/blog', label: 'Blog' },
                { href: '/docs', label: 'Documentation' },
                { href: '/changelog', label: 'Changelog' },
                { href: '/roadmap', label: 'Roadmap' },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-text-secondary hover:text-white transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2.5">
              {[
                { href: '/privacy', label: 'Privacy Policy' },
                { href: '/terms', label: 'Terms of Service' },
                { href: '/cookies', label: 'Cookie Policy' },
              ].map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-sm text-text-secondary hover:text-white transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="section-divider mb-6" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-text-muted text-sm">
            © {new Date().getFullYear()} VisionMint AI. All rights reserved.
          </p>
          <p className="text-text-muted text-sm flex items-center gap-1.5">
            Made with <Heart className="w-3.5 h-3.5 text-accent-purple fill-accent-purple" /> using Next.js & Hugging Face
          </p>
        </div>
      </div>
    </footer>
  );
}
