import { NextRequest, NextResponse } from 'next/server';
import { enhancePrompt, getNegativePrompt, ASPECT_RATIOS, type StyleKey, type AspectRatioKey, type ModelKey } from '@/utils/prompt-enhancer';
import { rateLimit } from '@/utils/rate-limit';
import { createAdminClient } from '@/lib/supabase/server';

export const runtime = 'nodejs';
export const maxDuration = 60;

const HF_API_BASE = 'https://api-inference.huggingface.co/models';

async function generateWithHuggingFace(
  model: string,
  prompt: string,
  width: number,
  height: number
): Promise<Buffer> {
  const apiKey = process.env.HUGGINGFACE_API_KEY;
  if (!apiKey) throw new Error('Hugging Face API key not configured');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 55_000);

  try {
    const response = await fetch(`${HF_API_BASE}/${model}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        Accept: 'image/png',
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          negative_prompt: getNegativePrompt(),
          width,
          height,
          num_inference_steps: 30,
          guidance_scale: 7.5,
          num_images_per_prompt: 1,
        },
        options: {
          wait_for_model: true,
          use_cache: false,
        },
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      const errText = await response.text().catch(() => 'Unknown error');
      
      // Handle model loading state
      if (response.status === 503) {
        throw new Error('Model is loading, please try again in 30 seconds');
      }
      if (response.status === 429) {
        throw new Error('Rate limit reached. Please wait a moment and try again');
      }
      if (response.status === 401) {
        throw new Error('Invalid API key. Please check your Hugging Face token');
      }
      
      throw new Error(`API Error (${response.status}): ${errText.slice(0, 200)}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } finally {
    clearTimeout(timeout);
  }
}

export async function POST(req: NextRequest) {
  try {
    // Get client IP for rate limiting
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0].trim() ||
      req.headers.get('x-real-ip') ||
      'anonymous';

    // Rate limit: 5 requests per minute per IP
    const rateLimitResult = rateLimit(`generate:${ip}`, 5, 60_000);
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: 'Too many requests. Please wait a minute before generating again.' },
        {
          status: 429,
          headers: {
            'X-RateLimit-Limit': '5',
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': new Date(rateLimitResult.resetAt).toISOString(),
          },
        }
      );
    }

    // Parse and validate request body
    const body = await req.json().catch(() => ({}));
    const {
      prompt,
      style = 'photorealistic',
      aspectRatio = '1:1',
      model = 'stabilityai/stable-diffusion-xl-base-1.0',
      userId,
    } = body as {
      prompt?: string;
      style?: StyleKey;
      aspectRatio?: AspectRatioKey;
      model?: ModelKey;
      userId?: string;
    };

    // Validate prompt
    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    if (prompt.trim().length > 500) {
      return NextResponse.json({ error: 'Prompt must be under 500 characters' }, { status: 400 });
    }

    // Validate model allowlist
    const allowedModels = [
      'stabilityai/stable-diffusion-xl-base-1.0',
      'runwayml/stable-diffusion-v1-5',
      'stabilityai/stable-diffusion-2-1',
    ];
    if (!allowedModels.includes(model)) {
      return NextResponse.json({ error: 'Invalid model selection' }, { status: 400 });
    }

    // Get dimensions from aspect ratio
    const ratioConfig = ASPECT_RATIOS[aspectRatio as AspectRatioKey];
    const { width, height } = ratioConfig || { width: 1024, height: 1024 };

    // Check and deduct credits if user is logged in
    let supabase: ReturnType<typeof createAdminClient> | null = null;
    let userRecord: { credits: number } | null = null;

    if (userId) {
      supabase = createAdminClient();
      const { data, error } = await supabase
        .from('users')
        .select('credits')
        .eq('id', userId)
        .single();

      if (error || !data) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }

      userRecord = data as { credits: number };

      if (userRecord.credits <= 0) {
        return NextResponse.json(
          { error: 'No credits remaining. Please upgrade your plan.' },
          { status: 402 }
        );
      }
    }

    // Enhance prompt
    const enhancedPrompt = enhancePrompt(prompt.trim(), style as StyleKey);

    // Generate image via Hugging Face
    const imageBuffer = await generateWithHuggingFace(model, enhancedPrompt, width, height);

    // Convert buffer to base64 data URL for response
    // In production, upload to Supabase Storage or Cloudinary
    const base64 = imageBuffer.toString('base64');
    const imageUrl = `data:image/png;base64,${base64}`;

    // Deduct credit and save to DB
    let imageId: string | undefined;
    let creditsRemaining: number | undefined;

    if (userId && supabase && userRecord) {
      // Deduct credit
      const newCredits = userRecord.credits - 1;
      await supabase
        .from('users')
        .update({ credits: newCredits })
        .eq('id', userId);

      creditsRemaining = newCredits;

      // Save image record (note: in production, store image in object storage, not base64)
      const { data: imageRecord } = await supabase
        .from('images')
        .insert({
          user_id: userId,
          prompt: prompt.trim(),
          enhanced_prompt: enhancedPrompt,
          image_url: imageUrl,
          style,
          aspect_ratio: aspectRatio,
          model,
        })
        .select('id')
        .single();

      imageId = (imageRecord as { id: string } | null)?.id;
    }

    return NextResponse.json({
      success: true,
      imageUrl,
      id: imageId,
      creditsRemaining,
      enhancedPrompt,
    });
  } catch (err) {
    console.error('Image generation error:', err);
    const message = err instanceof Error ? err.message : 'Failed to generate image';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({ status: 'VisionMint AI Image API is running' });
}
