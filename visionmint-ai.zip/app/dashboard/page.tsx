import type { Metadata } from 'next';
import { Suspense } from 'react';
import Navbar from '@/components/layout/Navbar';
import ImageGenerator from '@/components/ui/ImageGenerator';

export const metadata: Metadata = {
  title: 'AI Image Generator Dashboard',
  description:
    'Generate stunning AI images from text prompts. Choose art styles, aspect ratios, and download your creations instantly.',
  robots: { index: false, follow: false },
};

interface DashboardPageProps {
  searchParams: { prompt?: string };
}

export default function DashboardPage({ searchParams }: DashboardPageProps) {
  const initialPrompt = searchParams.prompt
    ? decodeURIComponent(searchParams.prompt)
    : '';

  return (
    <div className="min-h-screen bg-bg-primary">
      <Navbar />
      <Suspense fallback={null}>
        <ImageGenerator initialPrompt={initialPrompt} />
      </Suspense>
    </div>
  );
}
