import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

// Using Picsum photos as sample gallery (in production, these would be real HF-generated images)
const sampleImages = [
  { id: 1, src: 'https://picsum.photos/seed/vm1/600/600', prompt: 'Magical forest at twilight', style: 'Fantasy Art' },
  { id: 2, src: 'https://picsum.photos/seed/vm2/600/900', prompt: 'Cyberpunk city neon lights', style: 'Cyberpunk' },
  { id: 3, src: 'https://picsum.photos/seed/vm3/600/400', prompt: 'Mountain landscape photorealistic', style: 'Photorealistic' },
  { id: 4, src: 'https://picsum.photos/seed/vm4/600/600', prompt: 'Anime warrior princess', style: 'Anime' },
  { id: 5, src: 'https://picsum.photos/seed/vm5/600/400', prompt: 'Watercolor painting seascape', style: 'Watercolor' },
  { id: 6, src: 'https://picsum.photos/seed/vm6/600/600', prompt: 'Oil painting portrait masterpiece', style: 'Oil Painting' },
];

export default function GallerySection() {
  return (
    <section className="relative py-24 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-12 gap-4">
          <div>
            <div className="inline-flex items-center badge badge-cyan mb-3">Gallery</div>
            <h2 className="font-display text-4xl sm:text-5xl font-bold">
              See What&apos;s Possible
            </h2>
            <p className="text-text-secondary mt-3 text-lg max-w-lg">
              Real images created with VisionMint AI by our community
            </p>
          </div>
          <Link
            href="/dashboard"
            className="flex items-center gap-2 px-5 py-2.5 glass rounded-xl text-sm font-semibold hover:border-accent-purple/30 transition-all group shrink-0"
          >
            Create yours
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Masonry-style grid */}
        <div className="columns-2 md:columns-3 gap-4 space-y-4">
          {sampleImages.map((img) => (
            <div key={img.id} className="image-card break-inside-avoid group cursor-pointer">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={img.src}
                alt={img.prompt}
                className="w-full h-auto block"
                loading="lazy"
              />
              <div className="overlay">
                <div>
                  <p className="text-white text-xs font-medium line-clamp-2 mb-1">{img.prompt}</p>
                  <span className="badge badge-purple text-[10px]">{img.style}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Link href="/dashboard" className="btn-glow inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-semibold relative z-10">
            Start Creating for Free
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
