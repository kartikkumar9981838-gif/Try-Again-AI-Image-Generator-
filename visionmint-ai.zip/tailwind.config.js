/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: '#0B0F1A',
          secondary: '#111827',
        },
        accent: {
          purple: '#7C3AED',
          cyan: '#22D3EE',
          'purple-light': '#9D5FF3',
          'cyan-light': '#67E8F9',
        },
        text: {
          primary: '#FFFFFF',
          secondary: '#9CA3AF',
          muted: '#6B7280',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'glow-purple': 'radial-gradient(circle at center, rgba(124,58,237,0.3) 0%, transparent 70%)',
        'glow-cyan': 'radial-gradient(circle at center, rgba(34,211,238,0.2) 0%, transparent 70%)',
        'mesh-gradient': `
          radial-gradient(at 40% 20%, rgba(124,58,237,0.15) 0px, transparent 50%),
          radial-gradient(at 80% 0%, rgba(34,211,238,0.1) 0px, transparent 50%),
          radial-gradient(at 0% 50%, rgba(124,58,237,0.1) 0px, transparent 50%),
          radial-gradient(at 80% 50%, rgba(34,211,238,0.08) 0px, transparent 50%),
          radial-gradient(at 0% 100%, rgba(124,58,237,0.1) 0px, transparent 50%)
        `,
      },
      animation: {
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'shimmer': 'shimmer 2s linear infinite',
        'spin-slow': 'spin 8s linear infinite',
        'gradient-shift': 'gradient-shift 4s ease infinite',
      },
      keyframes: {
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(124,58,237,0.4)' },
          '50%': { boxShadow: '0 0 40px rgba(124,58,237,0.8), 0 0 60px rgba(34,211,238,0.3)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-12px)' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'gradient-shift': {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
      },
      backdropBlur: {
        xs: '2px',
      },
      boxShadow: {
        'glow-purple': '0 0 30px rgba(124,58,237,0.5)',
        'glow-cyan': '0 0 30px rgba(34,211,238,0.4)',
        'glow-sm': '0 0 15px rgba(124,58,237,0.3)',
        'glass': '0 8px 32px rgba(0,0,0,0.4)',
      },
    },
  },
  plugins: [],
};
