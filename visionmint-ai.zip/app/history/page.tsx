'use client';

import { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import { Download, Trash2, Search, Image as ImageIcon } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

interface HistoryImage {
  id: string;
  prompt: string;
  image_url: string;
  style: string;
  aspect_ratio: string;
  created_at: string;
}

export default function HistoryPage() {
  const [images, setImages] = useState<HistoryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    fetchHistory();
  }, []);

  async function fetchHistory() {
    setLoading(true);
    try {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        setImages([]);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('images')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setImages(data as HistoryImage[]);
      }
    } catch (err) {
      console.error('Failed to fetch history:', err);
    } finally {
      setLoading(false);
    }
  }

  async function deleteImage(id: string) {
    setDeleting(id);
    try {
      const supabase = createClient();
      const { error } = await supabase.from('images').delete().eq('id', id);
      if (!error) {
        setImages((prev) => prev.filter((img) => img.id !== id));
      }
    } catch (err) {
      console.error('Failed to delete:', err);
    } finally {
      setDeleting(null);
    }
  }

  async function downloadImage(url: string, id: string) {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `visionmint-${id}.png`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch {
      window.open(url, '_blank');
    }
  }

  const filtered = images.filter((img) =>
    img.prompt.toLowerCase().includes(search.toLowerCase()) ||
    img.style.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-bg-primary mesh-bg">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold gradient-text">My Gallery</h1>
            <p className="text-text-secondary mt-2">
              {images.length} image{images.length !== 1 ? 's' : ''} generated
            </p>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
            <input
              type="text"
              placeholder="Search prompts..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-dark pl-9 pr-4 py-2.5 text-sm w-64"
            />
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-square glass shimmer rounded-2xl" />
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center min-h-[400px] glass rounded-2xl">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-accent-purple/20 to-accent-cyan/10 flex items-center justify-center mb-5 border border-white/5">
              <ImageIcon className="w-10 h-10 text-accent-purple/60" />
            </div>
            <h3 className="text-xl font-bold mb-2">
              {search ? 'No results found' : 'No images yet'}
            </h3>
            <p className="text-text-secondary text-sm mb-6">
              {search
                ? 'Try a different search term'
                : 'Generate your first image to see it here'}
            </p>
            {!search && (
              <a href="/dashboard" className="btn-glow px-6 py-2.5 rounded-xl text-sm font-semibold relative z-10">
                Generate Images
              </a>
            )}
          </div>
        )}

        {/* Image Grid */}
        {!loading && filtered.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filtered.map((img) => (
              <div key={img.id} className="image-card group">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={img.image_url}
                  alt={img.prompt}
                  className="w-full aspect-square object-cover"
                  loading="lazy"
                />
                <div className="overlay">
                  <div className="w-full">
                    <p className="text-white text-xs font-medium line-clamp-2 mb-2">{img.prompt}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex gap-1">
                        <span className="badge badge-purple text-[10px]">{img.style}</span>
                      </div>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => downloadImage(img.image_url, img.id)}
                          className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
                          title="Download"
                        >
                          <Download className="w-3.5 h-3.5 text-white" />
                        </button>
                        <button
                          onClick={() => deleteImage(img.id)}
                          disabled={deleting === img.id}
                          className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/40 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-400" />
                        </button>
                      </div>
                    </div>
                    <p className="text-text-muted text-[10px] mt-1">
                      {new Date(img.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
