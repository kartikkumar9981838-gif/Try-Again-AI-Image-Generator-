'use client';

import { useState, useCallback } from 'react';
import { Sparkles, Download, RefreshCw, Zap, AlertCircle, Image as ImageIcon } from 'lucide-react';
import { STYLE_PRESETS, ASPECT_RATIOS, AI_MODELS, EXAMPLE_PROMPTS, type StyleKey, type AspectRatioKey, type ModelKey } from '@/utils/prompt-enhancer';
import { cn } from '@/utils/cn';

interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  timestamp: Date;
}

interface ImageGeneratorProps {
  initialPrompt?: string;
  userId?: string;
  userCredits?: number;
}

export default function ImageGenerator({ initialPrompt = '', userId, userCredits = 0 }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [style, setStyle] = useState<StyleKey>('photorealistic');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioKey>('1:1');
  const [model, setModel] = useState<ModelKey>('stabilityai/stable-diffusion-xl-base-1.0');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [credits, setCredits] = useState(userCredits);

  const generate = useCallback(async (customPrompt?: string) => {
    const finalPrompt = customPrompt || prompt;
    if (!finalPrompt.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: finalPrompt, style, aspectRatio, model, userId }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate image');
      }

      const newImage: GeneratedImage = {
        id: data.id || Date.now().toString(),
        url: data.imageUrl,
        prompt: finalPrompt,
        style,
        aspectRatio,
        timestamp: new Date(),
      };

      setImages((prev) => [newImage, ...prev]);
      if (data.creditsRemaining !== undefined) {
        setCredits(data.creditsRemaining);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [prompt, style, aspectRatio, model, userId]);

  const downloadImage = async (url: string, filename: string) => {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch {
      window.open(url, '_blank');
    }
  };

  const aspectRatioClass = {
    '1:1': 'aspect-square',
    '16:9': 'aspect-video',
    '9:16': 'aspect-[9/16]',
    '4:3': 'aspect-[4/3]',
  }[aspectRatio] || 'aspect-square';

  return (
    <div className="min-h-screen pt-16 mesh-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

          {/* ─── Left Panel: Controls ─── */}
          <div className="lg:col-span-2 space-y-5">
            {/* Credits */}
            {userId && (
              <div className="glass p-4 flex items-center justify-between">
                <span className="text-text-secondary text-sm">Available Credits</span>
                <div className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-accent-cyan" />
                  <span className="font-bold text-accent-cyan text-lg">{credits}</span>
                </div>
              </div>
            )}

            {/* Prompt Input */}
            <div className="glass p-5">
              <label className="block text-sm font-semibold text-white mb-3">
                Your Prompt
                <span className="text-text-muted font-normal ml-2">{prompt.length}/500</span>
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value.slice(0, 500))}
                placeholder="Describe the image you want to create..."
                rows={5}
                className="w-full input-dark px-4 py-3 text-sm leading-relaxed resize-none"
              />
              {/* Example prompts */}
              <div className="mt-3">
                <p className="text-xs text-text-muted mb-2">Quick examples:</p>
                <div className="flex flex-wrap gap-1.5">
                  {EXAMPLE_PROMPTS.slice(0, 3).map((p, i) => (
                    <button
                      key={i}
                      onClick={() => setPrompt(p)}
                      className="text-xs px-2.5 py-1 glass-sm hover:border-accent-purple/30 text-text-secondary hover:text-white transition-all truncate max-w-full"
                    >
                      {p.slice(0, 40)}…
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Style Selector */}
            <div className="glass p-5">
              <label className="block text-sm font-semibold text-white mb-3">Art Style</label>
              <div className="grid grid-cols-2 gap-2">
                {(Object.entries(STYLE_PRESETS) as [StyleKey, typeof STYLE_PRESETS[StyleKey]][]).map(([key, val]) => (
                  <button
                    key={key}
                    onClick={() => setStyle(key)}
                    className={cn(
                      'px-3 py-2 rounded-xl text-xs font-medium text-left transition-all duration-200 border',
                      style === key
                        ? 'bg-accent-purple/20 border-accent-purple/50 text-white'
                        : 'glass-sm border-transparent text-text-secondary hover:border-white/10 hover:text-white'
                    )}
                  >
                    {val.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio */}
            <div className="glass p-5">
              <label className="block text-sm font-semibold text-white mb-3">Aspect Ratio</label>
              <div className="grid grid-cols-2 gap-2">
                {(Object.entries(ASPECT_RATIOS) as [AspectRatioKey, typeof ASPECT_RATIOS[AspectRatioKey]][]).map(([key, val]) => (
                  <button
                    key={key}
                    onClick={() => setAspectRatio(key)}
                    className={cn(
                      'px-3 py-2.5 rounded-xl text-xs font-medium transition-all duration-200 border',
                      aspectRatio === key
                        ? 'bg-accent-cyan/10 border-accent-cyan/40 text-accent-cyan'
                        : 'glass-sm border-transparent text-text-secondary hover:border-white/10 hover:text-white'
                    )}
                  >
                    {val.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Model Selector */}
            <div className="glass p-5">
              <label className="block text-sm font-semibold text-white mb-3">AI Model</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value as ModelKey)}
                className="w-full select-dark px-4 py-2.5 text-sm"
              >
                {(Object.entries(AI_MODELS) as [ModelKey, typeof AI_MODELS[ModelKey]][]).map(([key, val]) => (
                  <option key={key} value={key}>{val.label}</option>
                ))}
              </select>
              <p className="text-xs text-text-muted mt-2">
                {AI_MODELS[model].description}
              </p>
            </div>

            {/* Generate Button */}
            <button
              onClick={() => generate()}
              disabled={loading || !prompt.trim()}
              className="w-full btn-glow py-4 text-base font-bold rounded-2xl relative z-10 flex items-center justify-center gap-3 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:shadow-none disabled:hover:transform-none"
            >
              {loading ? (
                <>
                  <div className="flex gap-1">
                    <span className="loading-dot w-2 h-2 bg-white rounded-full inline-block" />
                    <span className="loading-dot w-2 h-2 bg-white rounded-full inline-block" />
                    <span className="loading-dot w-2 h-2 bg-white rounded-full inline-block" />
                  </div>
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Generate Image
                  <span className="text-sm opacity-70">(-1 credit)</span>
                </>
              )}
            </button>

            {/* Error */}
            {error && (
              <div className="glass p-4 flex items-start gap-3 border-red-500/20">
                <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-red-400">Generation Failed</p>
                  <p className="text-xs text-text-secondary mt-1">{error}</p>
                </div>
              </div>
            )}
          </div>

          {/* ─── Right Panel: Results ─── */}
          <div className="lg:col-span-3">
            {loading && (
              <div className="glass rounded-2xl overflow-hidden mb-5">
                <div className={cn('relative w-full shimmer bg-bg-secondary flex items-center justify-center', aspectRatioClass)}>
                  <div className="text-center">
                    <div className="relative w-16 h-16 mx-auto mb-4">
                      <div className="absolute inset-0 rounded-full border-2 border-accent-purple/30 animate-spin-slow" />
                      <div className="absolute inset-2 rounded-full border-2 border-accent-cyan/40 animate-[spin_4s_linear_infinite_reverse]" />
                      <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-accent-purple animate-pulse" />
                    </div>
                    <p className="text-text-secondary text-sm font-medium">Creating your image...</p>
                    <p className="text-text-muted text-xs mt-1">This may take 5–15 seconds</p>
                  </div>
                  {/* Scan line animation */}
                  <div className="absolute inset-0 overflow-hidden pointer-events-none">
                    <div
                      className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-accent-cyan/60 to-transparent"
                      style={{ animation: 'ai-scan 2s linear infinite' }}
                    />
                  </div>
                </div>
              </div>
            )}

            {images.length === 0 && !loading && (
              <div className="glass rounded-2xl flex items-center justify-center aspect-square">
                <div className="text-center p-8">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-accent-purple/20 to-accent-cyan/10 flex items-center justify-center mx-auto mb-5 border border-white/5">
                    <ImageIcon className="w-10 h-10 text-accent-purple/60" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">Your Canvas Awaits</h3>
                  <p className="text-text-secondary text-sm max-w-xs">
                    Enter a prompt and click Generate to create your first AI image
                  </p>
                </div>
              </div>
            )}

            {/* Generated Images Grid */}
            {images.length > 0 && (
              <div className="grid grid-cols-1 gap-5">
                {images.map((img) => (
                  <div key={img.id} className="glass rounded-2xl overflow-hidden group">
                    {/* Image */}
                    <div className={cn('relative w-full overflow-hidden', aspectRatioClass)}>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={img.url}
                        alt={img.prompt}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        loading="lazy"
                      />
                    </div>

                    {/* Controls */}
                    <div className="p-4 flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-text-secondary line-clamp-2">{img.prompt}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="badge badge-purple text-[10px]">{img.style}</span>
                          <span className="badge badge-cyan text-[10px]">{img.aspectRatio}</span>
                          <span className="text-xs text-text-muted">
                            {img.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => generate(img.prompt)}
                          className="p-2 glass-sm hover:border-accent-purple/30 text-text-secondary hover:text-white transition-all"
                          title="Regenerate"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => downloadImage(img.url, `visionmint-${img.id}.png`)}
                          className="p-2 glass-sm hover:border-accent-cyan/30 text-text-secondary hover:text-accent-cyan transition-all"
                          title="Download"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
