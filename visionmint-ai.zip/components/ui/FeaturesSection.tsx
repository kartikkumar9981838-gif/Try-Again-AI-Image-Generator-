import { Zap, Image, Download, History, Palette, Shield } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Generate stunning images in 5–15 seconds using state-of-the-art Stable Diffusion models.',
    gradient: 'from-yellow-400 to-orange-500',
    glow: 'rgba(234,179,8,0.2)',
  },
  {
    icon: Image,
    title: 'Multiple Styles',
    description: 'Choose from 8 unique art styles — photorealistic, anime, oil painting, cyberpunk, and more.',
    gradient: 'from-accent-purple to-purple-400',
    glow: 'rgba(124,58,237,0.2)',
  },
  {
    icon: Palette,
    title: 'Smart Prompt Enhancement',
    description: 'Our AI automatically enhances your prompts for better, more detailed image outputs.',
    gradient: 'from-accent-cyan to-blue-400',
    glow: 'rgba(34,211,238,0.2)',
  },
  {
    icon: Download,
    title: 'Free Downloads',
    description: 'Download all your generated images in full resolution, completely free of charge.',
    gradient: 'from-green-400 to-emerald-500',
    glow: 'rgba(52,211,153,0.2)',
  },
  {
    icon: History,
    title: 'Image History',
    description: 'Never lose a creation. All your generated images are saved in your personal gallery.',
    gradient: 'from-pink-400 to-rose-500',
    glow: 'rgba(244,114,182,0.2)',
  },
  {
    icon: Shield,
    title: 'Secure & Private',
    description: 'Your images and prompts are private. Secured with Supabase auth and row-level security.',
    gradient: 'from-violet-400 to-indigo-500',
    glow: 'rgba(139,92,246,0.2)',
  },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 sm:py-32 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center badge badge-cyan mb-4">
            Why VisionMint AI
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold mb-5">
            Everything You Need to Create
          </h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">
            Powerful features wrapped in a simple, beautiful interface. No learning curve, 
            just results.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              className="glass p-6 group hover:border-white/10 transition-all duration-300"
              style={{
                animationDelay: `${i * 100}ms`,
              }}
            >
              {/* Icon */}
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}
                style={{ boxShadow: `0 8px 25px ${feature.glow}` }}
              >
                <feature.icon className="w-6 h-6 text-white" />
              </div>

              <h3 className="text-lg font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-text-secondary text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
