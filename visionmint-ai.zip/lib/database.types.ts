export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          created_at: string;
          credits: number;
          full_name: string | null;
          avatar_url: string | null;
        };
        Insert: {
          id: string;
          email: string;
          credits?: number;
          full_name?: string | null;
          avatar_url?: string | null;
        };
        Update: {
          credits?: number;
          full_name?: string | null;
          avatar_url?: string | null;
        };
      };
      images: {
        Row: {
          id: string;
          user_id: string;
          prompt: string;
          enhanced_prompt: string | null;
          image_url: string;
          style: string;
          aspect_ratio: string;
          model: string;
          created_at: string;
        };
        Insert: {
          user_id: string;
          prompt: string;
          enhanced_prompt?: string | null;
          image_url: string;
          style: string;
          aspect_ratio: string;
          model: string;
        };
        Update: {
          image_url?: string;
        };
      };
    };
  };
};
